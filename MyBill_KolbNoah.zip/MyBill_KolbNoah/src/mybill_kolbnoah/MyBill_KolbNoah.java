/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mybill_kolbnoah;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.io.PrintWriter;
import javax.swing.*;    
public class MyBill_KolbNoah
{
    public static void main(String[] args)
    {
        double tuitionFee,cost=0,finalCost,creditHrs=0,techFee=16.00,caps=15.00,stuSupFee=35.00;
        int tuition=0; // dialogButton;
        String input="", name;
        
        name = JOptionPane.showInputDialog("What is your name");
        
        Object[] Tuition = {"Yes", "No"};
        int n = JOptionPane.showOptionDialog(null,
         "Are you paying for In State Tuition?",
         "Choose a colour",
        JOptionPane.DEFAULT_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        Tuition,
        Tuition[0]);
           /*dialogButton = JOptionPane.YES_NO_OPTION;
            JOptionPane.showConfirmDialog (null, "Are you paying for In State Tuition?" ,"Billign Calculator", dialogButton);
            if(dialogButton == JOptionPane.YES_OPTION) {
                 tuition =1;}
            if(dialogButton == JOptionPane.NO_OPTION) {
                 tuition =2;}*/
        if(n==0){tuition =1;}
        if(n==1){tuition =2;}
        /*Scanner input = new Scanner(System.in);
        System.out.println("Are receiving In State tuition?");
        System.out.println("1.Yes");
        System.out.println("2.No");
         int tuition  = input.nextInt();*/
       
        if(tuition == 1)
        {
            cost = 76.00;
        }
        if(tuition == 2)
        {
            cost = 268.00;
        }
        //System.out.println("Enter number of Credit Hours");
        input = JOptionPane.showInputDialog("How many credit Hours?");
        creditHrs = Double.parseDouble(input);
        
        if(creditHrs >= 16){creditHrs = 16;}
        tuitionFee= creditHrs*cost;
        finalCost = tuitionFee+techFee +caps+stuSupFee;
        JOptionPane.showMessageDialog(null,name+
        "\n               Activity Fee:      $"+stuSupFee+
        "\nCampus access Fee:    $"+caps+
        "\n         Technology Fee:  $"+techFee+
        "\n                Tuition Fee:     $"+tuitionFee+
        "\n_______________________________"+
        "\n                         Total:    $"+finalCost);
        
        /*System.out.println("     Activity Fee: "+stuSupFee);
        System.out.println("Campus access Fee: "+caps);
        System.out.println("   Technology Fee: "+techFee);
        System.out.println("      Tuition Fee: "+tuitionFee);
        System.out.println("_______________________________");
        System.out.println("            Total: "+finalCost);
        */
        
    }
    
}